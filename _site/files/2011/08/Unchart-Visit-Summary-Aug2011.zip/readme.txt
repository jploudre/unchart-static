Readme
======

These files can be used to create your own Visit Summary Theme for e-MDs Solution Series. This probably works on version 7.0 through 7.2. I don't know how it'll work after that.

--Jonathan Ploudre
jploudre@gmail.com